let students = [
    {"id": 1, "name":"Tabby"},
    {"id": 2, "name":"Bruno"},
    {"id": 3, "name": "Kapesh"},
    {"id": 4, "name": "Lola"},
    {"id": 5, "name": "James"},

];
module.exports = students;