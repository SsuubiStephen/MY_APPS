const express = require('express');
const app = express();
const port = 5000;

//Service support
const my_business_logic = require('./service/my_business_logic');


// GET
//Greetings
app.get('/greetings', (request, response) => {
    return response.send({msg: "Hello Steve"});
});


app.listen(port, () => {

    console.log(`Example app listening at http://localhost:${port}`);
});
//List of friends
let students = [
    {"id": 1, "name":"Tabby"},
    {"id": 2, "name":"Bruno"},
    {"id": 3, "name": "Kapesh"},
    {"id": 4, "name": "Lola"},
    {"id": 5, "name": "James"},

];

app.get('list-of-friends', (request, response) => {
    return response.send(friends);
})
